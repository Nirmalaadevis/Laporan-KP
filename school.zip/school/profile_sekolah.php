<!DOCTYPE html>
<html lang="zxx">
<head>
<title>SDN PANYIRAPAN 01</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Scholarly web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--// Meta tag Keywords -->
<!-- css files -->
<link rel="stylesheet" href="css/bootstrap.css"> <!-- Bootstrap-Core-CSS -->
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
<link rel="stylesheet" href="css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
<link rel="stylesheet" href="css/swipebox.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300" rel="stylesheet">
<link rel="stylesheet" href="css/jquery-ui.css" />
<!-- //css files -->
<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Exo+2:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=cyrillic,latin-ext" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
<!-- //online-fonts -->
<style>
img {
	height : auto;
	margin-top:20px;
	margin-left:20px;
}

p {
	margin-top : 20px;
	color : #000000
}

h3 {
	margin-top : 50px;
}

</style>
</head>
<body>

<?php include ('napigasi.php'); ?>

<!--- gambar -->
				
				<div class="jumbotron">
					<div class="container">
						<div class="thumb" >
							<img src="images/icon_gambar.ico" alt="sekolah">
							<center><h2>Sambutan Kepala Sekolah</h2></center>
					<p align = "justify">Bismillahirrahmanirrahiim.<br>
					puji serta syukur saya panjatkan kepada Tuhan Yang Maha Esa yang telah memberikan rahmat dan anugerahNya sehingga website SEKOLAH DASAR NEGERI PANYIRAPAN 01 ini dapat muncul di dunia pendidikan. Saya selaku kepala sekolah SDN Panyirapan 01 merasa senang dengan adanya website ini yang dibuat dengan tujuan untuk memberikan segala informasi dengan memanfaatkan sarana teknologi informasi yang ada. <br>
					<br>
					Semoga dengan adanya website ini dapat membantu masyarakat untuk mengenal lebih jauh profil SDN Panyirapan 01 melalui website official dan menjadi manfaat, terutama dalam hal informasi yang berhubungan dengan pendidikan, ilmu pengetahuan dan informasi seputar sekolah. <br>
					</p></align>
				</div>
				</div>
				</div>
				<div class="jumbotron">
					<div class="container">
						<center><h2>Visi dan Misi</h2></center>
						<h3> VISI</h3>
						<p>“Terwujudnya Warga Sekolah Yang Cantik (Cerdas, Agamis, Nasionalis, Terampil, Inovatif Dan Kreatif).”</p></align>
						<h3> MISI</h3>
						<p align = "justify">- Mengoptimalkan Proses Pembelajaran Dan Bimbimngan.</p></align>
						<p align = "justify">- Menanamkan Keimanan Dan Ketaqwaan Terhadap Tuhan Yang Maha Esa Melalui Pengamalan Agama..</p></align>
						<p align = "justify">- Menumbuhkan Pribadi Yang Berwawasan Kebangsaan Menuju Masa Depan Yang Cemerlang.</p></align>
						<p align = "justify">- Mengembangkan Bidang Iptek Berdasarkan Minat, Bakat, Dan Potensi Yang Dimiliki.</p></align>
						<p align = "justify">- Menyelenggarakan Berbagai Kegiatan Social Yang Menjadi Bagian Pendidikan Karakter Bangsa.</p></align>
						<p align = "justify">- Mengembangkan Berbagai Kegiatan Dalam Proses Belajar Dikelas Yang Berbasis Profil Pelajaran Pancasila.</p></align>
					</div>
				</div>
					
<!--- //gambar -->

<!-- footer -->

<div class="w3layouts_copy_right">
	<div class="container">
		<p>2022 SDN PANYIRAPAN 01 | Design by <a href="http://w3layouts.com">W3layouts.</a></p>
	</div>
</div>
<!-- //footer -->

<!-- js-scripts -->			
<!-- js-files -->
<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
<!-- //js-files -->
<!-- Baneer-js -->


<!-- smooth scrolling -->
<script src="js/SmoothScroll.min.js"></script>
<!-- //smooth scrolling -->
<!-- stats -->
<script type="text/javascript" src="js/numscroller-1.0.js"></script>
<!-- //stats -->
<!-- moving-top scrolling -->
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
</script>
	<script type="text/javascript">
		$(document).ready(function() {
		/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
		*/								
		$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!-- //moving-top scrolling -->
<!-- gallery popup -->
<script src="js/jquery.swipebox.min.js"></script> 
<script type="text/javascript">
jQuery(function($) {
	$(".swipebox").swipebox();
});
</script>
<!-- //gallery popup -->
<!--/script-->
	<script src="js/simplePlayer.js"></script>
			<script>
				$("document").ready(function() {
					$("#video").simplePlayer();
				});
			</script>
<!-- //Baneer-js -->
<!-- Calendar -->
<script src="js/jquery-ui.js"></script>
	<script>
	  $(function() {
		$( "#datepicker" ).datepicker();
	 });
	</script>
<!-- //Calendar -->	

<!-- //js-scripts -->
</body>
</html>