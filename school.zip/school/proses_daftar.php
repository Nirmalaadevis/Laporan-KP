<?php
include 'koneksi.php';

$password = md5($_POST['password']);

$sql = mysql_query("SELECT * FROM `akun` WHERE username = '$_POST[username]' ") or die(mysql_error());
if(mysql_num_rows($sql) == 0)
{
	$input_akun="INSERT INTO `akun` (`username`, `password`, `level`) VALUES ('$_POST[username]', '$password', '1');";

	$input_murid="INSERT INTO `guru` (`nip`, `nama_guru`, `no_hp`, `jenkel`, `agama`) VALUES ('$_POST[Nip]', '$_POST[Nama_Guru]', '$_POST[No_Hp]', '$_POST[Jenis_Kelamin]', '$_POST[Agama]');";

	echo (" <SCRIPT LANGUAGE='JavaScript'>
				window.alert('Berhasil Registrasi')
				window.location.href='index.php';
			</SCRIPT>");
	(mysql_query($input_akun));
	(mysql_query($input_guru));
}	
else
{
	echo (" <SCRIPT LANGUAGE='JavaScript'>
				window.alert('Registrasi Gagal Username sudah Terdaftar')
				window.location.href='index.php';
			</SCRIPT>");
}


?>
